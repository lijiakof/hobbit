ender.ender({
  klass: require('klass')
})